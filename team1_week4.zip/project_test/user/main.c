/* Bit shifter */
#define BIT(x)                                  (1 << (x))

/* Base address */
#define RCC_BASE_ADDR                           0x40021000
#define PORT_A_BASE_ADDR                        0x40010800
#define PORT_B_BASE_ADDR                        0x40010C00
#define PORT_C_BASE_ADDR                        0x40011000
#define PORT_D_BASE_ADDR                        0x40011400

/* RCC */
#define GPIOx_CRL_ADDR_OFFSET                   0x00
#define RCC_APB2ENR_ADDR_OFFSET                 0x18
#define RCC_APB2ENR                             ((volatile unsigned *)(RCC_BASE_ADDR + RCC_APB2ENR_ADDR_OFFSET))
#define RCC_APB2ENR_IOPAEN                      0x00000004
#define RCC_APB2ENR_IOPBEN                      0x00000008
#define RCC_APB2ENR_IOPCEN                      0x00000010
#define RCC_APB2ENR_IOPDEN                      0x00000020

/* Port configuration register low/high */
#define GPIOx_CRH_ADDR_OFFSET                   0x04
#define GPIOA_CRL                               ((volatile unsigned *)(PORT_A_BASE_ADDR + GPIOx_CRL_ADDR_OFFSET))
#define GPIOB_CRL                               ((volatile unsigned *)(PORT_B_BASE_ADDR + GPIOx_CRL_ADDR_OFFSET))
#define GPIOB_CRH                               ((volatile unsigned *)(PORT_B_BASE_ADDR + GPIOx_CRH_ADDR_OFFSET))
#define GPIOC_CRL                               ((volatile unsigned *)(PORT_C_BASE_ADDR + GPIOx_CRL_ADDR_OFFSET))
#define GPIOC_CRH                               ((volatile unsigned *)(PORT_C_BASE_ADDR + GPIOx_CRH_ADDR_OFFSET))
#define GPIOD_CRL                               ((volatile unsigned *)(PORT_D_BASE_ADDR + GPIOx_CRL_ADDR_OFFSET))
#define GPIOD_CRH                               ((volatile unsigned *)(PORT_D_BASE_ADDR + GPIOx_CRH_ADDR_OFFSET))

/* Bit set/reset register */
#define GPIOx_BSRR_ADDR_OFFSET                  0x10
#define GPIOx_BRR_ADDR_OFFSET                   0x14
#define GPIOC_BSRR                              ((volatile unsigned *)(PORT_C_BASE_ADDR + GPIOx_BSRR_ADDR_OFFSET))
#define GPIOC_BRR                               ((volatile unsigned *)(PORT_C_BASE_ADDR + GPIOx_BRR_ADDR_OFFSET))

/* Input data register */
#define GPIOx_IDR_ADDR_OFFSET                   0x08
#define GPIOA_IDR                               ((volatile unsigned *)(PORT_A_BASE_ADDR + GPIOx_IDR_ADDR_OFFSET))
#define GPIOB_IDR                               ((volatile unsigned *)(PORT_B_BASE_ADDR + GPIOx_IDR_ADDR_OFFSET))
#define GPIOC_IDR                               ((volatile unsigned *)(PORT_C_BASE_ADDR + GPIOx_IDR_ADDR_OFFSET))
#define GPIOD_IDR                               ((volatile unsigned *)(PORT_D_BASE_ADDR + GPIOx_IDR_ADDR_OFFSET))

void delay() {
  int i;
  for (i = 0; i < 10000000; i++) {}
}

int main() {
    /* RCC: IOPBEN, IOPCEN, IOPDEN */
    *RCC_APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_IOPCEN | RCC_APB2ENR_IOPDEN;
    
    
    /* Port configuration register */
    
    // #### TODO 1: Port configuration for Key button ####
    // KEY Button: PC4, PB10, PC13, PA0 - input mode with pull-up / pull-down
    *GPIOC_CRL &= ~0x000F0000;
    *GPIOC_CRL |= 0x00080000;
    *GPIOB_CRH &= ~0x00000F00;
    *GPIOB_CRH |= 0x00000800;
    *GPIOC_CRH &= ~0x00F00000;
    *GPIOC_CRH |= 0x00800000;
    *GPIOA_CRL &= ~0x0000000F;
    *GPIOA_CRL |= 0x00000008;
    // #### TODO 1 ####
    
    
    // #### TODO 2: Port configuration for Relay module ####
    // Relay module: PC8, PC9 - General purpose output push-pull mode
    *GPIOC_CRH &= ~0x000000FF;
    *GPIOC_CRH |= 0x00000011;
    // #### TODO 2 ####

    // #### TODO 3: turn off the relays ####
    *GPIOC_BRR |= BIT(8) | BIT(9);
    // #### TODO 3 ####

    
    // #### TODO 4: Main Algorithm ####
    while (1) {
        /* check KEY IDR */
        // KEY input: pull-down
        if (!(*GPIOC_IDR & BIT(4))) {
            // KEY1 (PC4) is pressed
            *GPIOC_BSRR |= BIT(8);
        }
        else if (!(*GPIOB_IDR & BIT(10))) {
            // KEY2 (PB10) is pressed
            *GPIOC_BSRR |= BIT(9);
        }
        else if (!(*GPIOC_IDR & BIT(13))) {
            // KEY3 (PC13) is pressed
            *GPIOC_BSRR |= BIT(8);
            delay();
            *GPIOC_BRR |= BIT(8);
            *GPIOC_BSRR |= BIT(9);
            delay();
            *GPIOC_BRR |= BIT(9);
        }
        else if (!(*GPIOA_IDR & BIT(0))) {
            *GPIOC_BRR |= BIT(8) | BIT(9);
        }
    }
    // #### TODO 4 ####
}